import { n as createComponent, q as h } from "./index-C_9ZqZx5.js";
const QSpace = createComponent({
  name: "QSpace",
  setup() {
    const space = h("div", { class: "q-space" });
    return () => space;
  }
});
export {
  QSpace as Q
};
//# sourceMappingURL=QSpace-CN10jCLy.js.map
