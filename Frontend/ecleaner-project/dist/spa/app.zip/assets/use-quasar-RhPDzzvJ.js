import { x as inject, bG as quasarKey } from "./index-C_9ZqZx5.js";
function useQuasar() {
  return inject(quasarKey);
}
export {
  useQuasar as u
};
//# sourceMappingURL=use-quasar-RhPDzzvJ.js.map
